#include "minimumspanningtreealgorithm.h"

MinimumSpanningtreeAlgorithm::MinimumSpanningtreeAlgorithm() {
  generator = std::mt19937(randomdevice());
}
